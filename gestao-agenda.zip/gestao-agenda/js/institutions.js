/**
 * js/institutions.js
 * ============================================================
 * MÓDULO DE INSTITUIÇÕES
 * — CRUD completo (criar, listar, editar, excluir)
 * — Chips de filtro na agenda
 * — Seletor no modal de eventos
 * ============================================================
 */

const AppInstitutions = (() => {

  let _uid  = null;
  let _list = []; // cache local

  // ---- Carrega do Firestore ----
  async function load(uid) {
    _uid  = uid;
    _list = await AppDB.getInstitutions(uid);
    renderList();
    renderFilterChips();
    renderSelectOptions();
  }

  // ---- Retorna lista em cache ----
  function getList() { return _list; }

  // ---- Encontra instituição por nome ou sigla ----
  function findByNameOrAbbr(text) {
    const upper = text.toUpperCase();
    return _list.find(inst => {
      const nameUp = (inst.name || "").toUpperCase();
      const abbrUp = (inst.abbr || "").toUpperCase();
      return (abbrUp && upper.includes(abbrUp)) || upper.includes(nameUp);
    }) || null;
  }

  // ---- Renderiza lista de cards ----
  function renderList() {
    const container = document.getElementById("inst-list");
    if (!container) return;

    if (_list.length === 0) {
      container.innerHTML = '<p class="empty-state">Nenhuma instituição cadastrada.<br>Clique em "+ Nova" para começar.</p>';
      return;
    }

    container.innerHTML = _list.map(inst => `
      <div class="inst-card" data-id="${inst.id}" style="--inst-color:${inst.color || '#2563EB'}">
        <div class="inst-card-left">
          <div class="inst-color-dot" style="background:${inst.color || '#2563EB'}"></div>
          <div>
            <div class="inst-card-name">${esc(inst.name)}</div>
            <div class="inst-card-abbr">${inst.abbr ? esc(inst.abbr) : '—'} ${inst.cnpj ? '· CNPJ: ' + esc(inst.cnpj) : ''}</div>
          </div>
        </div>
        <span class="inst-card-edit">Editar ›</span>
      </div>
    `).join("");

    container.querySelectorAll(".inst-card").forEach(card => {
      card.addEventListener("click", () => openModal(card.dataset.id));
    });
  }

  // ---- Chips de filtro na agenda ----
  function renderFilterChips() {
    const row = document.getElementById("inst-filter-row");
    if (!row) return;

    // Mantém o "Todos"
    const allChip = row.querySelector('[data-inst="all"]');
    row.innerHTML = "";
    if (allChip) row.appendChild(allChip);

    _list.forEach(inst => {
      const chip = document.createElement("button");
      chip.className = "inst-chip";
      chip.dataset.inst = inst.id;
      chip.textContent = inst.abbr || inst.name;
      chip.style.setProperty("--chip-color", inst.color || "#2563EB");
      chip.addEventListener("click", () => {
        document.querySelectorAll(".inst-chip").forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        AppEvents.filterByInstitution(inst.id);
      });
      row.appendChild(chip);
    });

    // "Todos" clicável
    const all = row.querySelector('[data-inst="all"]');
    if (all) {
      all.addEventListener("click", () => {
        document.querySelectorAll(".inst-chip").forEach(c => c.classList.remove("active"));
        all.classList.add("active");
        AppEvents.filterByInstitution("all");
      });
    }
  }

  // ---- Select de instituições no modal de evento ----
  function renderSelectOptions() {
    const sel = document.getElementById("ev-institution");
    if (!sel) return;
    // Mantém a opção vazia
    sel.innerHTML = '<option value="">— Sem vínculo —</option>';
    _list.forEach(inst => {
      const opt = document.createElement("option");
      opt.value = inst.id;
      opt.textContent = `${inst.name}${inst.abbr ? ' (' + inst.abbr + ')' : ''}`;
      sel.appendChild(opt);
    });
  }

  // ---- Abre modal para nova instituição ----
  function openModal(id = null) {
    const inst = id ? _list.find(i => i.id === id) : null;
    document.getElementById("modal-inst-title").textContent = inst ? "Editar Instituição" : "Nova Instituição";
    document.getElementById("inst-name").value  = inst?.name  || "";
    document.getElementById("inst-abbr").value  = inst?.abbr  || "";
    document.getElementById("inst-cnpj").value  = inst?.cnpj  || "";
    document.getElementById("inst-phone").value = inst?.phone || "";
    document.getElementById("inst-color").value = inst?.color || "#2563EB";
    document.getElementById("inst-id").value    = inst?.id    || "";

    const btnDel = document.getElementById("btn-delete-inst");
    btnDel.classList.toggle("hidden", !inst);

    UI.openModal("modal-inst");
  }

  // ---- Salva ----
  async function handleSave() {
    const name  = document.getElementById("inst-name").value.trim();
    const id    = document.getElementById("inst-id").value;
    if (!name) { UI.showToast("Informe o nome da instituição."); return; }

    const data = {
      name,
      abbr:  document.getElementById("inst-abbr").value.trim().toUpperCase(),
      cnpj:  document.getElementById("inst-cnpj").value.trim(),
      phone: document.getElementById("inst-phone").value.trim(),
      color: document.getElementById("inst-color").value,
    };

    try {
      UI.showLoading("btn-save-inst", "Salvando...");
      await AppDB.saveInstitution(_uid, data, id || null);
      UI.showToast(id ? "Instituição atualizada ✔" : "Instituição criada ✔");
      await load(_uid);
      UI.closeModal("modal-inst");
    } catch (e) {
      console.error(e);
      UI.showToast("Erro ao salvar. Tente novamente.");
    }
    UI.hideLoading("btn-save-inst", "Salvar");
  }

  // ---- Exclui ----
  async function handleDelete() {
    const id = document.getElementById("inst-id").value;
    if (!id) return;
    if (!confirm("Excluir esta instituição? Os eventos vinculados perderão o vínculo.")) return;
    try {
      await AppDB.deleteInstitution(_uid, id);
      UI.showToast("Instituição removida.");
      await load(_uid);
      UI.closeModal("modal-inst");
    } catch (e) {
      console.error(e);
      UI.showToast("Erro ao excluir.");
    }
  }

  // ---- Init ----
  function init(uid) {
    _uid = uid;
    document.getElementById("btn-new-inst")?.addEventListener("click", () => openModal());
    document.getElementById("btn-save-inst")?.addEventListener("click", handleSave);
    document.getElementById("btn-delete-inst")?.addEventListener("click", handleDelete);
  }

  // ---- Util ----
  function esc(str) {
    return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }

  return { init, load, getList, findByNameOrAbbr, openModal, renderSelectOptions };
})();
