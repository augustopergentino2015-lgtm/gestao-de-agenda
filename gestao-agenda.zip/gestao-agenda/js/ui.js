/**
 * js/ui.js
 * ============================================================
 * UTILITÁRIOS DE INTERFACE
 * — Modais (abrir / fechar)
 * — Toast notifications
 * — Loading states em botões
 * — Navegação por abas (bottom nav)
 * ============================================================
 */

const UI = (() => {

  // ====================================================
  // MODAIS
  // ====================================================

  function openModal(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    // Foco no primeiro input
    setTimeout(() => el.querySelector("input,textarea,select")?.focus(), 100);
  }

  function closeModal(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.add("hidden");
    document.body.style.overflow = "";
  }

  function initModalCloseButtons() {
    document.querySelectorAll(".modal-close, [data-close]").forEach(btn => {
      btn.addEventListener("click", () => {
        const target = btn.dataset.close || btn.closest(".modal-overlay")?.id;
        if (target) closeModal(target);
      });
    });

    // Fechar clicando no overlay
    document.querySelectorAll(".modal-overlay").forEach(overlay => {
      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) closeModal(overlay.id);
      });
    });

    // Fechar com ESC
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        document.querySelectorAll(".modal-overlay:not(.hidden)").forEach(m => closeModal(m.id));
      }
    });
  }

  // ====================================================
  // TOAST
  // ====================================================

  let _toastTimer = null;

  function showToast(msg, duration = 3000) {
    const el = document.getElementById("toast");
    if (!el) return;
    el.textContent = msg;
    el.classList.remove("hidden");
    if (_toastTimer) clearTimeout(_toastTimer);
    _toastTimer = setTimeout(() => el.classList.add("hidden"), duration);
  }

  // ====================================================
  // LOADING STATES
  // ====================================================

  function showLoading(btnId, text = "Aguarde...") {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn._originalText = btn.textContent;
    btn.textContent   = text;
    btn.disabled      = true;
    btn.style.opacity = ".7";
  }

  function hideLoading(btnId, text = null) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.textContent   = text || btn._originalText || "OK";
    btn.disabled      = false;
    btn.style.opacity = "1";
  }

  // ====================================================
  // TABS (BOTTOM NAV)
  // ====================================================

  function initBottomNav() {
    document.querySelectorAll(".nav-item").forEach(btn => {
      btn.addEventListener("click", () => {
        const tab = btn.dataset.tab;
        switchTab(tab);
      });
    });
  }

  function switchTab(tabName) {
    // Painel
    document.querySelectorAll(".tab-panel").forEach(p => {
      p.classList.toggle("active", p.id === `tab-${tabName}`);
      p.classList.toggle("hidden", p.id !== `tab-${tabName}`);
    });
    // Nav buttons
    document.querySelectorAll(".nav-item").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.tab === tabName);
    });
  }

  // ====================================================
  // SYNC INDICATOR
  // ====================================================

  function showSyncing() {
    document.getElementById("screen-app")?.classList.add("syncing");
  }
  function hideSyncing() {
    document.getElementById("screen-app")?.classList.remove("syncing");
  }

  // ====================================================
  // INIT
  // ====================================================

  function init() {
    initModalCloseButtons();
    initBottomNav();
  }

  return { init, openModal, closeModal, showToast, showLoading, hideLoading, showSyncing, hideSyncing, switchTab };
})();

// ====================================================
// AppUI — Gerencia telas principais
// ====================================================
const AppUI = (() => {

  function showSplash()       { show("splash"); }
  function hideSplash()       { document.getElementById("splash")?.classList.add("hidden"); }
  function goToAuth()         { hideAll(); show("screen-auth"); }
  function goToProfileSetup() { hideAll(); show("screen-profile-setup"); }
  function goToApp()          { hideAll(); show("screen-app"); }

  function hideAll() {
    ["screen-auth", "screen-profile-setup", "screen-app"].forEach(id => {
      document.getElementById(id)?.classList.add("hidden");
    });
  }
  function show(id) { document.getElementById(id)?.classList.remove("hidden"); }

  return { showSplash, hideSplash, goToAuth, goToProfileSetup, goToApp };
})();
