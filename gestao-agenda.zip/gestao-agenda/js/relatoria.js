/**
 * js/relatoria.js
 * ============================================================
 * MOTOR DE INTELIGÊNCIA POR RELATORIA
 *
 * Processa texto livre e extrai:
 *   1. Datas (DD/MM/AAAA, DD/MM/AA, "dia 15", "15 de julho", etc.)
 *   2. Horários (14h, 14:30, às 9h)
 *   3. Menciona de Instituições cadastradas (por nome ou sigla)
 *   4. Título do evento (sentença mais próxima à data)
 *
 * Após extração, mostra preview e aguarda confirmação do usuário.
 * ============================================================
 */

const AppRelatoria = (() => {

  // ====================================================
  // REGEX PATTERNS
  // ====================================================

  const MONTHS_PT = {
    janeiro:1, fevereiro:2, março:3, março:3, abril:4, maio:5, junho:6,
    julho:7, agosto:8, setembro:9, outubro:10, novembro:11, dezembro:12,
    jan:1, fev:2, mar:3, abr:4, mai:5, jun:6,
    jul:7, ago:8, set:9, out:10, nov:11, dez:12
  };

  // Padrão: "15/07/2025", "15/07/25", "15.07.2025"
  const RE_DATE_NUMERIC = /\b(\d{1,2})[\/\.\-](\d{1,2})[\/\.\-](\d{2,4})\b/g;

  // Padrão: "dia 15", "no dia 15"
  const RE_DATE_DAY_ONLY = /\b(?:dia|no dia)\s+(\d{1,2})\b/gi;

  // Padrão: "15 de julho", "15 de julho de 2025"
  const RE_DATE_TEXTUAL = /\b(\d{1,2})\s+de\s+(janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\b(?:\s+de\s+(\d{4}))?/gi;

  // Padrão: "14h", "14:30", "às 9h30", "14h00"
  const RE_TIME = /\b(?:às?\s+)?(\d{1,2})h(?:(\d{2})|(?:\s*(\d{2})))?\b|(\d{1,2}):(\d{2})\b/gi;

  // ====================================================
  // EXTRACTION
  // ====================================================

  function extractDates(text) {
    const dates = [];
    const now   = new Date();
    const year  = now.getFullYear();

    // Datas numéricas
    let m;
    const re1 = new RegExp(RE_DATE_NUMERIC.source, "g");
    while ((m = re1.exec(text)) !== null) {
      const d = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10);
      let y = parseInt(m[3], 10);
      if (y < 100) y += 2000;
      if (d >= 1 && d <= 31 && mo >= 1 && mo <= 12) {
        dates.push({ dateStr: toISO(y, mo, d), index: m.index });
      }
    }

    // Datas textuais: "15 de julho de 2025"
    const re2 = new RegExp(RE_DATE_TEXTUAL.source, "gi");
    while ((m = re2.exec(text)) !== null) {
      const d  = parseInt(m[1], 10);
      const mo = MONTHS_PT[m[2].toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"")];
      const y  = m[3] ? parseInt(m[3], 10) : year;
      if (d >= 1 && d <= 31 && mo) {
        dates.push({ dateStr: toISO(y, mo, d), index: m.index });
      }
    }

    // "dia 15" — usa mês atual
    const re3 = new RegExp(RE_DATE_DAY_ONLY.source, "gi");
    while ((m = re3.exec(text)) !== null) {
      const d  = parseInt(m[1], 10);
      const mo = now.getMonth() + 1;
      if (d >= 1 && d <= 31) {
        dates.push({ dateStr: toISO(year, mo, d), index: m.index });
      }
    }

    // Remove duplicatas por dateStr
    const seen = new Set();
    return dates.filter(d => {
      if (seen.has(d.dateStr)) return false;
      seen.add(d.dateStr);
      return true;
    }).sort((a, b) => a.index - b.index);
  }

  function extractTime(text, fromIndex) {
    // Procura o primeiro horário após fromIndex
    const slice = text.slice(fromIndex, fromIndex + 200);
    RE_TIME.lastIndex = 0;
    const m = RE_TIME.exec(slice);
    if (!m) return "";
    const h = parseInt(m[1] || m[4], 10);
    const min = parseInt(m[2] || m[3] || m[5] || "0", 10);
    return `${String(h).padStart(2,"0")}:${String(min).padStart(2,"0")}`;
  }

  function extractTitle(text, fromIndex, toIndex) {
    // Pega o trecho entre datas e limpa pontuação
    const slice = text.slice(Math.max(0, fromIndex - 120), fromIndex).trim();
    // Pega a última sentença/frase antes da data
    const sentences = slice.split(/[.;!?\n]/);
    const last = sentences[sentences.length - 1].trim();
    if (last.length > 5 && last.length < 120) return capitalize(last);

    // Fallback: trecho após a data
    const after = text.slice(fromIndex, fromIndex + 80).replace(/[\d\/\.\-]+/g, "").trim();
    return after.length > 3 ? capitalize(after) : "Compromisso";
  }

  // ====================================================
  // INSTITUTION MATCHING
  // ====================================================

  function matchInstitution(text, dateIndex) {
    // Procura no trecho de ±150 chars ao redor da data
    const start  = Math.max(0, dateIndex - 150);
    const end    = Math.min(text.length, dateIndex + 150);
    const slice  = text.slice(start, end).toUpperCase();
    const inst   = AppInstitutions.findByNameOrAbbr(slice);
    return inst || null;
  }

  // ====================================================
  // PROCESS (main)
  // ====================================================

  let _pendingEvents = [];

  function process(uid) {
    const text = document.getElementById("relatoria-input").value;
    if (!text.trim()) { UI.showToast("Digite ou cole um texto para processar."); return; }

    const dates = extractDates(text);
    if (dates.length === 0) {
      UI.showToast("Nenhuma data encontrada no texto.");
      return;
    }

    _pendingEvents = dates.map((d, i) => {
      const nextIdx = dates[i + 1]?.index ?? text.length;
      const time  = extractTime(text, d.index);
      const title = extractTitle(text, d.index, nextIdx);
      const inst  = matchInstitution(text, d.index);
      return {
        date: d.dateStr,
        time,
        title,
        institutionId: inst?.id || "",
        _instName: inst?.name || "",
        _instColor: inst?.color || "#2563EB",
      };
    });

    renderPreview();
    document.getElementById("relatoria-preview").classList.remove("hidden");
  }

  function renderPreview() {
    const container = document.getElementById("relatoria-results");
    container.innerHTML = _pendingEvents.map((ev, i) => {
      const [y, mo, d] = ev.date.split("-");
      const datePT = `${d}/${mo}/${y}`;
      return `
        <div class="relatoria-item" style="--item-color:${ev._instColor}">
          <div class="relatoria-item-date">📅 ${datePT} ${ev.time ? "· ⏰ " + ev.time : ""}</div>
          <div>
            <input class="relatoria-title-input" data-idx="${i}" value="${esc(ev.title)}"
              style="width:100%;border:1px solid var(--border);border-radius:6px;padding:6px 10px;margin:6px 0;font-size:.9rem" />
          </div>
          ${ev._instName ? `<div class="relatoria-item-inst">🏛 ${esc(ev._instName)}</div>` : ""}
        </div>`;
    }).join("");

    // Permite editar o título inline
    container.querySelectorAll(".relatoria-title-input").forEach(inp => {
      inp.addEventListener("input", () => {
        _pendingEvents[parseInt(inp.dataset.idx)].title = inp.value;
      });
    });
  }

  async function confirmAll(uid) {
    if (_pendingEvents.length === 0) return;
    try {
      UI.showLoading("btn-confirm-relatoria", "Lançando...");
      for (const ev of _pendingEvents) {
        const { _instName, _instColor, ...data } = ev;
        await AppDB.saveEvent(uid, data);
      }
      UI.showToast(`${_pendingEvents.length} evento(s) lançado(s) ✔`);
      document.getElementById("relatoria-input").value = "";
      document.getElementById("relatoria-preview").classList.add("hidden");
      _pendingEvents = [];
      // Recarrega agenda do dia atual
      AppEvents.loadForDate(uid, new Date());
    } catch (e) {
      console.error(e);
      UI.showToast("Erro ao lançar eventos.");
    }
    UI.hideLoading("btn-confirm-relatoria", "✔ Confirmar Todos");
  }

  // ====================================================
  // HELPERS
  // ====================================================

  function toISO(y, mo, d) {
    return `${y}-${String(mo).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
  }

  function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  function esc(str) {
    return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }

  // ====================================================
  // INIT
  // ====================================================

  function init(uid) {
    document.getElementById("btn-process-relatoria")?.addEventListener("click", () => process(uid));
    document.getElementById("btn-confirm-relatoria")?.addEventListener("click", () => confirmAll(uid));
    document.getElementById("btn-cancel-relatoria")?.addEventListener("click", () => {
      document.getElementById("relatoria-preview").classList.add("hidden");
      _pendingEvents = [];
    });
  }

  return { init };
})();
