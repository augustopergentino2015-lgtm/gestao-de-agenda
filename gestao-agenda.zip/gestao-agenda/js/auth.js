/**
 * js/auth.js
 * ============================================================
 * AUTENTICAÇÃO — Login com e-mail/telefone, cadastro, logout.
 * Firebase Authentication garante isolamento de contas.
 * ============================================================
 */

const AppAuth = (() => {

  // ---- Toggle abas Login / Cadastro ----
  function initAuthTabs() {
    document.querySelectorAll(".auth-tab").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".auth-tab").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const target = btn.dataset.tab;
        document.getElementById("auth-login").classList.toggle("hidden", target !== "login");
        document.getElementById("auth-register").classList.toggle("hidden", target !== "register");
      });
    });
  }

  // ---- Mostrar / ocultar senha ----
  function initEyeButtons() {
    document.querySelectorAll(".eye-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const inp = document.getElementById(btn.dataset.target);
        if (!inp) return;
        inp.type = inp.type === "password" ? "text" : "password";
        btn.textContent = inp.type === "password" ? "👁" : "🙈";
      });
    });
  }

  // ---- Login ----
  async function handleLogin() {
    const id  = document.getElementById("login-identifier").value.trim();
    const pwd = document.getElementById("login-password").value;
    const err = document.getElementById("login-error");
    err.classList.add("hidden");

    if (!id || !pwd) {
      showError(err, "Preencha e-mail e senha."); return;
    }

    // Normaliza: se não for e-mail, tentamos prefixo de telefone
    let email = id;
    if (!id.includes("@")) {
      // Telefone: converte em e-mail fictício para o Firebase Auth
      email = phoneToEmail(id);
    }

    try {
      UI.showLoading("btn-login", "Entrando...");
      await AUTH.signInWithEmailAndPassword(email, pwd);
      // O observer em app.js cuida do redirecionamento
    } catch (e) {
      showError(err, friendlyAuthError(e.code));
      UI.hideLoading("btn-login", "Entrar");
    }
  }

  // ---- Cadastro ----
  async function handleRegister() {
    const email   = document.getElementById("reg-email").value.trim();
    const phone   = document.getElementById("reg-phone").value.trim();
    const pwd     = document.getElementById("reg-password").value;
    const confirm = document.getElementById("reg-confirm").value;
    const err     = document.getElementById("register-error");
    err.classList.add("hidden");

    if (!email && !phone) {
      showError(err, "Informe um e-mail ou telefone."); return;
    }
    if (pwd.length < 6) {
      showError(err, "A senha deve ter pelo menos 6 caracteres."); return;
    }
    if (pwd !== confirm) {
      showError(err, "As senhas não coincidem."); return;
    }

    const authEmail = email || phoneToEmail(phone);

    try {
      UI.showLoading("btn-register", "Criando conta...");
      await AUTH.createUserWithEmailAndPassword(authEmail, pwd);
    } catch (e) {
      showError(err, friendlyAuthError(e.code));
      UI.hideLoading("btn-register", "Criar conta");
    }
  }

  // ---- Logout ----
  async function handleLogout() {
    if (!confirm("Deseja sair da sua conta?")) return;
    AppDB.unsubscribeEvents();
    await AUTH.signOut();
  }

  // ---- Helpers ----
  function phoneToEmail(phone) {
    const digits = phone.replace(/\D/g, "");
    return `tel_${digits}@agenda.app`;
  }

  function showError(el, msg) {
    el.textContent = msg;
    el.classList.remove("hidden");
  }

  function friendlyAuthError(code) {
    const map = {
      "auth/user-not-found":       "Usuário não encontrado.",
      "auth/wrong-password":       "Senha incorreta.",
      "auth/email-already-in-use": "Este e-mail já está cadastrado.",
      "auth/invalid-email":        "E-mail inválido.",
      "auth/too-many-requests":    "Muitas tentativas. Tente mais tarde.",
      "auth/network-request-failed": "Sem conexão com a internet.",
    };
    return map[code] || "Erro de autenticação. Tente novamente.";
  }

  // ---- Init ----
  function init() {
    initAuthTabs();
    initEyeButtons();
    document.getElementById("btn-login")?.addEventListener("click", handleLogin);
    document.getElementById("btn-register")?.addEventListener("click", handleRegister);
    document.getElementById("btn-logout")?.addEventListener("click", handleLogout);
  }

  return { init };
})();
