/**
 * js/profile.js
 * ============================================================
 * MÓDULO DE PERFIL
 * — Formulário de setup obrigatório na 1ª vez
 * — Formulário de edição na aba Perfil
 * — Máscara de CPF/CNPJ e CEP
 * ============================================================
 */

const AppProfile = (() => {

  // ---- Coleta dados do formulário de setup ----
  function collectSetup() {
    return {
      name:         val("p-name"),
      cpf:          val("p-cpf"),
      phone:        val("p-tel"),
      role:         val("p-role"),
      address: {
        street:       val("p-street"),
        number:       val("p-number"),
        neighborhood: val("p-neighborhood"),
        city:         val("p-city"),
        state:        val("p-state"),
        cep:          val("p-cep"),
      }
    };
  }

  // ---- Coleta dados do formulário de perfil (aba) ----
  function collectEdit() {
    return {
      name:         val("prof-name"),
      cpf:          val("prof-cpf"),
      phone:        val("prof-tel"),
      role:         val("prof-role"),
      address: {
        street:       val("prof-street"),
        number:       val("prof-number"),
        neighborhood: val("prof-neighborhood"),
        city:         val("prof-city"),
        state:        val("prof-state"),
        cep:          val("prof-cep"),
      }
    };
  }

  // ---- Preenche aba de perfil com dados carregados ----
  function fillEditForm(profile) {
    setVal("prof-name",         profile.name || "");
    setVal("prof-cpf",          profile.cpf  || "");
    setVal("prof-tel",          profile.phone || "");
    setVal("prof-role",         profile.role  || "");
    const a = profile.address || {};
    setVal("prof-street",       a.street       || "");
    setVal("prof-number",       a.number       || "");
    setVal("prof-neighborhood", a.neighborhood || "");
    setVal("prof-city",         a.city         || "");
    setVal("prof-state",        a.state        || "");
    setVal("prof-cep",          a.cep          || "");
  }

  // ---- Salva setup ----
  async function handleSetupSave(uid) {
    const data = collectSetup();
    const err  = document.getElementById("profile-error");
    err.classList.add("hidden");

    if (!data.name || !data.cpf || !data.phone) {
      err.textContent = "Preencha os campos obrigatórios (*)";
      err.classList.remove("hidden");
      return false;
    }

    try {
      UI.showLoading("btn-save-profile", "Salvando...");
      await AppDB.saveProfile(uid, data);
      UI.hideLoading("btn-save-profile", "Salvar e Continuar →");
      return true;
    } catch (e) {
      console.error(e);
      err.textContent = "Erro ao salvar. Verifique sua conexão.";
      err.classList.remove("hidden");
      UI.hideLoading("btn-save-profile", "Salvar e Continuar →");
      return false;
    }
  }

  // ---- Salva edição ----
  async function handleEditSave(uid) {
    const data = collectEdit();
    const msg  = document.getElementById("profile-update-msg");
    msg.classList.add("hidden");

    try {
      UI.showLoading("btn-update-profile", "Salvando...");
      await AppDB.saveProfile(uid, data);
      msg.textContent = "✔ Perfil atualizado com sucesso!";
      msg.classList.remove("hidden");
      // Atualiza header
      updateHeader(data);
      UI.showToast("Perfil salvo ✔");
    } catch (e) {
      console.error(e);
      msg.textContent = "Erro ao salvar.";
      msg.style.color = "var(--danger)";
      msg.classList.remove("hidden");
    }
    UI.hideLoading("btn-update-profile", "Salvar Perfil");
  }

  // ---- Atualiza header com nome / cargo ----
  function updateHeader(profile) {
    const name = profile?.name || "";
    const role = profile?.role || "";
    const first = name.split(" ")[0] || "Usuário";
    document.getElementById("header-greeting").textContent = `Olá, ${first}`;
    document.getElementById("header-role").textContent = role;
    document.getElementById("header-avatar").textContent = first.charAt(0).toUpperCase();
  }

  // ---- Máscaras ----
  function applyMasks() {
    // CPF/CNPJ — setup
    maskCpfCnpj("p-cpf");
    maskCpfCnpj("prof-cpf");
    // CEP
    maskCep("p-cep");
    maskCep("prof-cep");
    // Telefone
    maskPhone("p-tel");
    maskPhone("prof-tel");
  }

  function maskCpfCnpj(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", () => {
      let v = el.value.replace(/\D/g, "");
      if (v.length <= 11) {
        v = v.replace(/(\d{3})(\d)/, "$1.$2")
             .replace(/(\d{3})(\d)/, "$1.$2")
             .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
      } else {
        v = v.replace(/(\d{2})(\d)/, "$1.$2")
             .replace(/(\d{3})(\d)/, "$1.$2")
             .replace(/(\d{3})(\d)/, "$1/$2")
             .replace(/(\d{4})(\d{1,2})$/, "$1-$2");
      }
      el.value = v;
    });
  }

  function maskCep(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", () => {
      let v = el.value.replace(/\D/g, "");
      if (v.length > 5) v = v.slice(0, 5) + "-" + v.slice(5, 8);
      el.value = v;
    });
  }

  function maskPhone(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener("input", () => {
      let v = el.value.replace(/\D/g, "");
      if (v.length > 10) {
        v = v.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3");
      } else {
        v = v.replace(/(\d{2})(\d{4})(\d{0,4})/, "($1) $2-$3");
      }
      el.value = v;
    });
  }

  // ---- Utils ----
  function val(id) {
    return (document.getElementById(id)?.value || "").trim();
  }
  function setVal(id, v) {
    const el = document.getElementById(id);
    if (el) el.value = v;
  }

  function init(uid) {
    applyMasks();
    document.getElementById("btn-save-profile")?.addEventListener("click", async () => {
      const ok = await handleSetupSave(uid);
      if (ok) AppUI.goToApp();
    });
    document.getElementById("btn-update-profile")?.addEventListener("click", () => handleEditSave(uid));
  }

  return { init, fillEditForm, updateHeader };
})();
