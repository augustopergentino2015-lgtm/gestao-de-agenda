/**
 * js/db.js
 * ============================================================
 * CAMADA DE DADOS — Todas as operações são isoladas por userId.
 * Nenhum usuário acessa dados de outro. Estrutura Firestore:
 *
 *   users/{userId}/profile       → documento único de perfil
 *   users/{userId}/institutions  → coleção de instituições
 *   users/{userId}/events        → coleção de eventos
 * ============================================================
 */

const AppDB = (() => {

  // --- Helpers de path ---
  const userRef   = (uid) => DB.collection("users").doc(uid);
  const profileRef   = (uid) => userRef(uid).collection("profile").doc("data");
  const instColl     = (uid) => userRef(uid).collection("institutions");
  const eventsColl   = (uid) => userRef(uid).collection("events");

  // ====================================================
  // PERFIL
  // ====================================================

  async function getProfile(uid) {
    const snap = await profileRef(uid).get();
    return snap.exists ? snap.data() : null;
  }

  async function saveProfile(uid, data) {
    await profileRef(uid).set({ ...data, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }, { merge: true });
  }

  // ====================================================
  // INSTITUIÇÕES
  // ====================================================

  async function getInstitutions(uid) {
    const snap = await instColl(uid).orderBy("name").get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  }

  async function saveInstitution(uid, data, id = null) {
    const payload = { ...data, updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
    if (id) {
      await instColl(uid).doc(id).set(payload, { merge: true });
      return id;
    } else {
      payload.createdAt = firebase.firestore.FieldValue.serverTimestamp();
      const ref = await instColl(uid).add(payload);
      return ref.id;
    }
  }

  async function deleteInstitution(uid, id) {
    await instColl(uid).doc(id).delete();
  }

  // ====================================================
  // EVENTOS
  // ====================================================

  async function getEvents(uid, dateStr = null) {
    let q = eventsColl(uid);
    if (dateStr) {
      q = q.where("date", "==", dateStr);
    }
    const snap = await q.orderBy("time").get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  }

  async function getEventsForDate(uid, dateStr) {
    return getEvents(uid, dateStr);
  }

  async function saveEvent(uid, data, id = null) {
    const payload = { ...data, updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
    if (id) {
      await eventsColl(uid).doc(id).set(payload, { merge: true });
      return id;
    } else {
      payload.createdAt = firebase.firestore.FieldValue.serverTimestamp();
      const ref = await eventsColl(uid).add(payload);
      return ref.id;
    }
  }

  async function deleteEvent(uid, id) {
    await eventsColl(uid).doc(id).delete();
  }

  // ====================================================
  // SINCRONIZAÇÃO: Listener em tempo real para eventos
  // ====================================================

  let _eventListener = null;

  function subscribeToEvents(uid, dateStr, callback) {
    if (_eventListener) _eventListener(); // cancela anterior
    _eventListener = eventsColl(uid)
      .where("date", "==", dateStr)
      .orderBy("time")
      .onSnapshot(snap => {
        const events = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        callback(events);
      }, err => console.error("Listener error:", err));
    return _eventListener;
  }

  function unsubscribeEvents() {
    if (_eventListener) { _eventListener(); _eventListener = null; }
  }

  return {
    getProfile, saveProfile,
    getInstitutions, saveInstitution, deleteInstitution,
    getEvents, getEventsForDate, saveEvent, deleteEvent,
    subscribeToEvents, unsubscribeEvents
  };
})();
