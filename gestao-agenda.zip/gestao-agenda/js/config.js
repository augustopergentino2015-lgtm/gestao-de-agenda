/**
 * js/config.js
 * ============================================================
 * CONFIGURAÇÃO DO FIREBASE
 *
 * INSTRUÇÕES:
 * 1. Acesse https://console.firebase.google.com
 * 2. Crie um projeto → clique em "Adicionar app" (Web)
 * 3. Copie os valores do firebaseConfig e cole aqui abaixo
 * 4. No Firebase Console, habilite:
 *    - Authentication → Email/Password
 *    - Firestore Database (modo produção)
 * 5. Em Firestore → Regras, cole as regras do arquivo FIREBASE_RULES.txt
 * ============================================================
 */

const FIREBASE_CONFIG = {
  apiKey:            "COLE_SUA_API_KEY_AQUI",
  authDomain:        "SEU_PROJETO.firebaseapp.com",
  projectId:         "SEU_PROJETO_ID",
  storageBucket:     "SEU_PROJETO.appspot.com",
  messagingSenderId: "SEU_MESSAGING_ID",
  appId:             "SEU_APP_ID"
};

// Inicializa o Firebase
firebase.initializeApp(FIREBASE_CONFIG);

// Instâncias globais
const AUTH = firebase.auth();
const DB   = firebase.firestore();

// Habilita persistência offline
DB.enablePersistence({ synchronizeTabs: true })
  .catch(err => console.warn("Persistência offline indisponível:", err.code));

console.log("🔥 Firebase inicializado.");
