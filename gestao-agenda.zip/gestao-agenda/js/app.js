/**
 * js/app.js
 * ============================================================
 * ORQUESTRADOR PRINCIPAL DO APP
 *
 * Fluxo:
 *   1. Splash → Firebase inicializa
 *   2. Auth observer decide: Auth / Profile Setup / App
 *   3. Se usuário logado e com perfil → carrega dados e entra no App
 *   4. Sincronização bidirecional:
 *      - Pull automático ao entrar
 *      - Push em cada novo evento/instituição (via AppDB)
 *      - Listener em tempo real para eventos do dia
 * ============================================================
 */

(function() {
  "use strict";

  let _uid     = null;
  let _profile = null;

  // ====================================================
  // BOOTSTRAP
  // ====================================================

  window.addEventListener("DOMContentLoaded", async () => {
    UI.init();
    AppAuth.init();
    registerServiceWorker();
    setupInstallBanner();

    // O observer do Firebase Auth gerencia o fluxo de telas
    AUTH.onAuthStateChanged(onAuthStateChange);
  });

  // ====================================================
  // AUTH STATE OBSERVER
  // ====================================================

  async function onAuthStateChange(user) {
    if (!user) {
      // Não logado → tela de auth
      _uid = null;
      setTimeout(() => {
        AppUI.hideSplash();
        AppUI.goToAuth();
      }, 800);
      return;
    }

    _uid = user.uid;

    try {
      // Verifica perfil
      _profile = await AppDB.getProfile(_uid);

      AppUI.hideSplash();

      if (!_profile || !_profile.name) {
        // Perfil incompleto → setup obrigatório
        AppProfile.init(_uid);
        AppUI.goToProfileSetup();
      } else {
        // Tudo OK → App
        await launchApp();
      }
    } catch (e) {
      console.error("Erro ao verificar perfil:", e);
      AppUI.hideSplash();
      AppUI.goToAuth();
    }
  }

  // ====================================================
  // LAUNCH APP
  // ====================================================

  async function launchApp() {
    AppUI.goToApp();

    // Init módulos
    AppProfile.init(_uid);
    AppEvents.init(_uid);
    AppInstitutions.init(_uid);
    AppRelatoria.init(_uid);

    // Sync: Pull dados
    await syncAll();

    // Btn sync manual
    document.getElementById("btn-sync")?.addEventListener("click", async () => {
      UI.showSyncing();
      await syncAll();
      UI.hideSyncing();
      UI.showToast("Dados sincronizados ✔");
    });
  }

  // ====================================================
  // SYNC BIDIRECIONAL
  // ====================================================

  async function syncAll() {
    if (!_uid) return;
    UI.showSyncing();

    try {
      // Carrega perfil e atualiza header
      _profile = await AppDB.getProfile(_uid);
      AppProfile.fillEditForm(_profile || {});
      AppProfile.updateHeader(_profile || {});

      // Carrega instituições (necessário antes dos eventos para vincular cores)
      await AppInstitutions.load(_uid);

      // Carrega eventos do dia (listener em tempo real)
      AppEvents.loadForDate(_uid, new Date());

      // Carrega D-1
      await AppEvents.loadD1(_uid);

    } catch (e) {
      console.error("Erro na sincronização:", e);
      UI.showToast("Erro ao sincronizar. Verifique sua conexão.");
    }

    UI.hideSyncing();
  }

  // ====================================================
  // SERVICE WORKER (PWA)
  // ====================================================

  function registerServiceWorker() {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/service-worker.js")
        .then(reg => console.log("✅ Service Worker registrado:", reg.scope))
        .catch(err => console.warn("⚠️ SW não registrado:", err));
    }
  }

  // ====================================================
  // INSTALL BANNER (A2HS)
  // ====================================================

  let _deferredInstallPrompt = null;

  function setupInstallBanner() {
    window.addEventListener("beforeinstallprompt", (e) => {
      e.preventDefault();
      _deferredInstallPrompt = e;

      // Mostra um toast convidando a instalar
      setTimeout(() => {
        UI.showToast("📲 Instale o app na tela inicial!", 5000);
      }, 3000);
    });
  }

})();
