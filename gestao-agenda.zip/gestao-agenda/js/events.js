/**
 * js/events.js
 * ============================================================
 * MÓDULO DE EVENTOS
 * — CRUD de eventos por data
 * — Navegação de dias
 * — Painel D-1 (Lembretes Críticos para amanhã)
 * — Filtro por instituição
 * — Listener em tempo real (Firestore)
 * ============================================================
 */

const AppEvents = (() => {

  let _uid         = null;
  let _currentDate = new Date();
  let _allEvents   = [];  // eventos do dia carregados
  let _filterInst  = "all";
  let _unsubscribe = null;

  // ====================================================
  // DATA NAVIGATION
  // ====================================================

  function toDateStr(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const dy = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${dy}`;
  }

  function tomorrowStr() {
    const t = new Date();
    t.setDate(t.getDate() + 1);
    return toDateStr(t);
  }

  function formatDateLabel(d) {
    const today    = toDateStr(new Date());
    const tomorrow = tomorrowStr();
    const ds       = toDateStr(d);
    if (ds === today)    return "Hoje";
    if (ds === tomorrow) return "Amanhã";
    const dias = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
    return dias[d.getDay()];
  }

  function formatDateFull(d) {
    return d.toLocaleDateString("pt-BR", { weekday:"long", day:"2-digit", month:"long", year:"numeric" });
  }

  function updateDateHeader() {
    document.getElementById("agenda-day-label").textContent = formatDateLabel(_currentDate);
    document.getElementById("agenda-full-date").textContent = formatDateFull(_currentDate);
  }

  // ====================================================
  // LOAD EVENTS (com listener em tempo real)
  // ====================================================

  function loadForDate(uid, date) {
    _uid = uid;
    _currentDate = date;
    updateDateHeader();

    if (_unsubscribe) { _unsubscribe(); _unsubscribe = null; }

    _unsubscribe = AppDB.subscribeToEvents(uid, toDateStr(date), (events) => {
      _allEvents = events;
      renderEvents();
    });
  }

  // ====================================================
  // RENDER EVENTS
  // ====================================================

  function renderEvents() {
    const container = document.getElementById("events-list");
    if (!container) return;

    let events = _allEvents;

    // Filtra por instituição
    if (_filterInst !== "all") {
      events = events.filter(e => e.institutionId === _filterInst);
    }

    if (events.length === 0) {
      container.innerHTML = `
        <div class="events-empty">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#CBD5E1" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
          <p>Sem eventos neste dia.</p>
          <button class="btn-link" id="btn-add-first">+ Adicionar evento</button>
        </div>`;
      document.getElementById("btn-add-first")?.addEventListener("click", () => openModal());
      return;
    }

    const institutions = AppInstitutions.getList();

    container.innerHTML = events.map(ev => {
      const inst = institutions.find(i => i.id === ev.institutionId);
      const color = inst?.color || "#2563EB";
      const [h, m] = (ev.time || "").split(":").map(Number);
      const ampm = h < 12 ? "AM" : "PM";
      const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
      const timeLabel = ev.time ? `${String(h12).padStart(2,"0")}:${String(m).padStart(2,"0")}` : "--";

      return `
        <div class="event-card" data-id="${ev.id}" style="--event-color:${color}">
          <div class="event-time-col">
            <div class="event-time">${timeLabel}</div>
            ${ev.time ? `<div class="event-ampm">${ampm}</div>` : ""}
          </div>
          <div class="event-body">
            <div class="event-title">${esc(ev.title)}</div>
            ${ev.location ? `<div class="event-meta">📍 ${esc(ev.location)}</div>` : ""}
            ${inst ? `<span class="event-inst-tag" style="--tag-bg:${color}22; --tag-color:${color}">${esc(inst.abbr || inst.name)}</span>` : ""}
          </div>
          ${ev.priority && ev.priority !== "normal" ? `<div class="event-priority-dot ${ev.priority}"></div>` : ""}
        </div>`;
    }).join("");

    container.querySelectorAll(".event-card").forEach(card => {
      card.addEventListener("click", () => openModal(card.dataset.id));
    });
  }

  // ====================================================
  // D-1 PANEL
  // ====================================================

  async function loadD1(uid) {
    const dateStr = tomorrowStr();
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    document.getElementById("d1-date").textContent =
      tomorrow.toLocaleDateString("pt-BR", { day:"2-digit", month:"short" });

    const events = await AppDB.getEventsForDate(uid, dateStr);
    const list   = document.getElementById("d1-list");
    if (!list) return;

    if (events.length === 0) {
      list.innerHTML = '<p class="d1-empty">Nenhum compromisso para amanhã.</p>';
      return;
    }

    const institutions = AppInstitutions.getList();
    list.innerHTML = events.map(ev => {
      const inst  = institutions.find(i => i.id === ev.institutionId);
      const color = inst?.color || "white";
      return `
        <div class="d1-item" style="--item-color:${color}">
          <div class="d1-item-time">${ev.time || "Sem horário"}</div>
          <div class="d1-item-title">${esc(ev.title)}</div>
          ${inst ? `<div class="d1-item-inst">${esc(inst.abbr || inst.name)}</div>` : ""}
        </div>`;
    }).join("");
  }

  // ====================================================
  // MODAL ADD / EDIT
  // ====================================================

  function openModal(id = null) {
    const event = id ? _allEvents.find(e => e.id === id) : null;

    document.getElementById("modal-event-title").textContent = event ? "Editar Evento" : "Novo Evento";
    document.getElementById("ev-id").value            = event?.id       || "";
    document.getElementById("ev-title").value         = event?.title    || "";
    document.getElementById("ev-date").value          = event?.date     || toDateStr(_currentDate);
    document.getElementById("ev-time").value          = event?.time     || "";
    document.getElementById("ev-location").value      = event?.location || "";
    document.getElementById("ev-notes").value         = event?.notes    || "";
    document.getElementById("ev-priority").value      = event?.priority || "normal";
    document.getElementById("ev-institution").value   = event?.institutionId || "";

    document.getElementById("btn-delete-event").classList.toggle("hidden", !event);

    UI.openModal("modal-event");
  }

  async function handleSave() {
    const title = document.getElementById("ev-title").value.trim();
    const date  = document.getElementById("ev-date").value;
    const id    = document.getElementById("ev-id").value;

    if (!title || !date) { UI.showToast("Título e data são obrigatórios."); return; }

    const data = {
      title,
      date,
      time:          document.getElementById("ev-time").value,
      location:      document.getElementById("ev-location").value.trim(),
      notes:         document.getElementById("ev-notes").value.trim(),
      priority:      document.getElementById("ev-priority").value,
      institutionId: document.getElementById("ev-institution").value,
    };

    try {
      UI.showLoading("btn-save-event", "Salvando...");
      await AppDB.saveEvent(_uid, data, id || null);
      UI.showToast(id ? "Evento atualizado ✔" : "Evento criado ✔");
      UI.closeModal("modal-event");
      // Recarrega D-1 se o evento é para amanhã
      if (data.date === tomorrowStr()) loadD1(_uid);
    } catch (e) {
      console.error(e);
      UI.showToast("Erro ao salvar evento.");
    }
    UI.hideLoading("btn-save-event", "Salvar");
  }

  async function handleDelete() {
    const id = document.getElementById("ev-id").value;
    if (!id) return;
    if (!confirm("Excluir este evento?")) return;
    try {
      await AppDB.deleteEvent(_uid, id);
      UI.showToast("Evento removido.");
      UI.closeModal("modal-event");
    } catch (e) {
      console.error(e);
      UI.showToast("Erro ao excluir.");
    }
  }

  // ====================================================
  // FILTER
  // ====================================================

  function filterByInstitution(instId) {
    _filterInst = instId;
    renderEvents();
  }

  // ====================================================
  // INIT
  // ====================================================

  function init(uid) {
    _uid = uid;

    document.getElementById("btn-prev-day")?.addEventListener("click", () => {
      _currentDate.setDate(_currentDate.getDate() - 1);
      loadForDate(uid, _currentDate);
    });
    document.getElementById("btn-next-day")?.addEventListener("click", () => {
      _currentDate.setDate(_currentDate.getDate() + 1);
      loadForDate(uid, _currentDate);
    });

    document.getElementById("btn-add-event")?.addEventListener("click", () => openModal());
    document.getElementById("btn-save-event")?.addEventListener("click", handleSave);
    document.getElementById("btn-delete-event")?.addEventListener("click", handleDelete);
  }

  // ---- Util ----
  function esc(str) {
    return String(str).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }

  return { init, loadForDate, loadD1, filterByInstitution, openModal, toDateStr };
})();
